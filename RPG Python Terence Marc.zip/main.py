import random, math, sys, os,py
import time
from time import sleep
with open("event.txt",mode="r") as dic:
    dico=[mot.rstrip('\n') for mot in dic]
with open("choix.txt",mode="r") as dic:
    bit=[mot.rstrip('\n') for mot in dic]
with open("event combat.txt",mode="r") as dic:
    dicko=[mot.rstrip('\n') for mot in dic]
with open("choix combat.txt",mode="r") as dic:
    gros=[mot.rstrip('\n') for mot in dic]
with open("enemi.txt",mode="r") as dic:
    por=[mot.rstrip('\n') for mot in dic] 

HP = 100
Exp = 0
Level = 0
Epee = 0
Armure = 0
Attaque = 0
Defense = 0
Pseudo = None
Evenements = 0
Choix = [range(4)]


sau=py.saucisse(HP,Exp,Level,Epee,Armure,Attaque,Defense)
JoueurEnVie=sau.JoueurEnVie(HP,Pseudo)
os.system('clear')
if JoueurEnVie==True:

  if Evenements == 0:
    Pseudo = input("Entre ton nom brave chevalier : ")
    sleep(0.1)
    os.system('clear')
    Evenements = 1

  if Evenements == 1:
    if sau.JoueurEnVie(HP,Pseudo)== False:
      print("t mort")
      sleep(100)
    b=sau.PointEXP(Exp,Armure,Epee)
    print("Niveau :",b[0])
    print("Attaque :" ,b[1], "/// Defense :", b[2], "/// Expérience :",Exp)
    sau.JoueurEnVie(HP,Pseudo)
    print("Tu es un chevalier débutant et tu dois faire tes preuves ! Es-tu prêt pour cette grande aventure ?","Chevalier "+Pseudo+".","\n 1 = « En avant ! »\n","2 = « Non j'ai peur ! »\n")
    Choix = 0
    
    while not (Choix ==1 or Choix == 2 or Choix == 3):
      try:
        Choix = int(input("Quel choix fais-tu ? "))
      except:
        print("Choix valide : 1, 2 ou 3")
      if Choix == 1:
        print("\nAlors, c'est parti mon kiki !\n")
        sleep(4)
        os.system('clear')
        Evenements = 2
      elif Choix == 2:
        print("\nToute façon t'as pas le choix ! Allez, je croyais que tu en avais plus dans le bide !\n")
        sleep(4)
        os.system('clear')
        HP = HP-100
        Evenements = 2
			
  if Evenements == 2:
    if sau.JoueurEnVie(HP,Pseudo)== False:
      print("t mort")
      sleep(100)
    b=sau.PointEXP(Exp,Armure,Epee)
    print("Niveau :",b[0])
    print("Attaque :" ,b[1], "/// Defense :", b[2], "/// Expérience :",Exp)
    sau.JoueurEnVie(HP,Pseudo)
    print("« Cher chevalier vous êtes envoyé dans une caverne à 20 kilomètres d’ici dans le but de récupérer le sceptre des huit légendes. Mais bien évidemment pour cela… tu dois accomplir les 20 kilomètres sans crever, mais ce sceptre des huit légendes maudit le royaume et fait apparaître des vilains monstres.","\n 1 = « Des monstres ? Pfff... Même pas peur ! »\n","2 = « Oh non ! JE VEUX PAS Y ALLER !!! »\n")
    Choix = 0
    
    while not (Choix ==1 or Choix == 2 or Choix == 3):
      try:
        Choix = int(input("Quel choix fais-tu ? "))
      except:
        print("Choix valide : 1, 2 ou 3")
      if Choix == 1:
        print("\n Alors allez-y mon brave, et ramenez-moi un grec !\n")
        sleep(4)
        print("Mais... t'as pas de thune pour un grec")
        sleep(1)
        print("cheh")
        sleep(2)
        os.system('clear')
        Evenements = 2
      elif Choix == 2:
        print("\n vous vous retournez pour renter chez vous quand soudain un des fameux dragons blancs aux yeux bleus de la mort qui tue sort d'un des buissons a proximité .\n","La fin approche pour vous .")
        sleep(4)
        print("cheh")
        sleep(2)
        os.system('clear')
        HP = HP-100
        Evenements = 2
#magasin

























for i in range(2000):
  print(random.choice(dico),"Chevalier "+Pseudo,"\n 1 = "+random.choice(bit)+"\n","\n 2 = "+random.choice(bit)+"\n")
  print(random.choice(dicko),"ce sont des "+random.choice(por),"\n 1 = "+random.choice(gros)+"\n","\n 2 = "+random.choice(gros)+"\n")

