import random, math, sys, os
import time
from time import sleep

class saucisse:
  def __init__(self,HP,Exp,Level,Epee,Armure,Attaque,Defense):
    self.hp=HP
    self.exp=Exp
    self.level=Level
    self.epee=Epee
    self.armure=Armure
    self.attaque=Attaque
    self.defense=Defense

  def Attaque(self,Epee):
    if Epee == 0:
      self.attaque = 10
      #print("Mains nues :", self.attaque, "ATK")
      return self.attaque
    elif Epee == 1:
      self.attaque = 15
      #print("Epée en bois :", self.attaque, "ATK")
      return self.attaque
    elif Epee == 2:
      self.attaque = 25
      #print("Epée en pierre :", self.attaque, "ATK")
      return self.attaque
    elif Epee == 3:
      self.attaque = 40
      #print("Epée en fer :", self.attaque, "ATK")
      return self.attaque
    elif Epee == 4:
      self.attaque = 60
      #print("Epée en diamant :", self.attaque, "ATK")
      return self.attaque
    elif Epee == 5:
      self.attaque = 100
      #print("Epée légendaire des huit légendes :", self.attaque, "ATK")
      return self.attaque

  def Defense(self,Armure):
    if Armure == 0:
      self.defense = 10
      #print("Vêtements simples :", self.defense, "DEF")
      return self.defense
    elif Armure == 1:
      self.defense = 15
      #print("Armure en cuir :", self.defense, "DEF")
      return self.defense
    elif Armure == 2:
      self.defense = 25
      #print("Armure en pierre :", self.defense, "DEF")
      return self.defense
    elif Armure == 3:
      self.defense = 40
      #print("Armure en fer :", self.defense, "DEF")
      return self.defense
    elif Armure == 4:
      self.defense = 60
      #print("Armure en diamant :", self.defense, "DEF")
      return self.defense
    elif Armure == 5:
      self.defense = 100
      #print("Armure légendaire des huit légendes :", self.defense, "DEF")
      return self.defense

  def PointEXP(self,Exp,Armure,Epee):
    self.attaque=self.Attaque(Epee)
    self.defense=self.Defense(Armure)

    if Exp <= 299:
      LEVEL = 1
      
      self.attaque = self.attaque*1.1
      self.defense = self.defense*1.1
      return LEVEL, self.attaque, self.defense
    elif Exp >= 300:
      LEVEL = 2
      
      self.attaque = self.attaque*1.2
      self.defense = self.defense*1.2
      return LEVEL, self.attaque, self.defense
    elif Exp >= 1000:
      LEVEL = 3
      
      self.attaque = self.attaque*1.3
      self.defense = self.defense*1.3
      return LEVEL, self.attaque, self.defense

  def JoueurEnVie(self,hp,Pseudo):
    if hp <= 0:
      os.system('clear')
      print("C'est dommage, tu es mort. Recommence chevalier " + Pseudo + " ! Redémarre le programme !")
      sleep(6)
      os.system('clear')
      return False
    if hp > 0:
      print("VIE :",hp)
      return True
